package com.beteselihom.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var english = false
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun tv(s: String, size: Float = 18f, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.DKGRAY)
            if (bold) setTypeface(null, 1)
            setPadding(24, 18, 24, 18)
        }

    private fun btn(s: String, action: () -> Unit) =
        Button(this).apply { text = s; setOnClickListener { action() } }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            setBackgroundColor(Color.rgb(13,71,161)); gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(tv(title, 21f, true).apply { setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn(if (english) "አማ" else "EN") { english = !english; showHome() })
        root.addView(bar)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,12,12,24) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun showHome() {
        val root = base(if (english) "Bete Selihom" else "ቤተ ሰልሖም")
        content.addView(tv(if (english) "Community Health Training Center" else "የማህበረሰብ ጤና ስልጠና ማዕከል", 24f, true))
        content.addView(tv(if (english) "Practical, modern and affordable health training." else "ተግባራዊ፣ ዘመናዊ እና ተመጣጣኝ የጤና ስልጠና።"))
        val labels = if (english)
            arrayOf("Trainings","Registration","About Us","Announcements","Certificate","Contact Us")
        else arrayOf("ስልጠናዎች","ምዝገባ","ስለ እኛ","ማስታወቂያ","ሰርቲፊኬት","ያግኙን")
        val actions = arrayOf<() -> Unit>(
            {showTrainings()},{showRegistration()},{showAbout()},
            {showAnnouncements()},{showCertificate()},{showContact()}
        )
        for (i in labels.indices) content.addView(btn(labels[i], actions[i]))
        setContentView(root)
    }

    private fun showTrainings() {
        val root=base(if(english) "Trainings" else "ስልጠናዎች")
        val list=if(english)
            arrayOf("Community Health","First Aid","CPR","Basic Life Support (BLS)","Maternal & Child Health","Nutrition & Hygiene","Health Project Consulting","Research & Data Analysis")
        else arrayOf("የማህበረሰብ ጤና","የመጀመሪያ እርዳታ (First Aid)","CPR","Basic Life Support (BLS)","የእናትና ሕፃናት ጤና","የምግብና ንጽህና","የጤና ፕሮጀክት ማማከር","የምርምርና ዳታ ትንተና")
        list.forEach { content.addView(tv("• $it")) }
        content.addView(btn(if(english)"Register" else "ምዝገባ"){showRegistration()})
        content.addView(btn(if(english)"Home" else "መነሻ"){showHome()})
        setContentView(root)
    }

    private fun showRegistration() {
        val root=base(if(english)"Registration" else "ምዝገባ")
        val name=EditText(this); name.hint=if(english)"Full name" else "ሙሉ ስም"
        val phone=EditText(this); phone.hint=if(english)"Phone number" else "ስልክ ቁጥር"; phone.inputType=2
        val training=EditText(this); training.hint=if(english)"Training requested" else "የሚፈልጉት ስልጠና"
        content.addView(name); content.addView(phone); content.addView(training)
        content.addView(btn(if(english)"Submit Registration" else "ምዝገባ አስገባ") {
            Toast.makeText(this, if(english)"Registration received." else "ምዝገባዎ ተቀብሏል።", Toast.LENGTH_LONG).show()
        })
        content.addView(btn(if(english)"Home" else "መነሻ"){showHome()})
        setContentView(root)
    }

    private fun showAbout() {
        val root=base(if(english)"About Us" else "ስለ እኛ")
        val s = if (english) {
            "Bete Selihom Community Health Training Center is a private training and consulting organization.\n\nVision: To become a leading community health training institution in Ethiopia.\n\nMission: To provide practical, modern and affordable health training.\n\nGoal: Train 300 participants in year one and build partnerships with more than 10 health institutions.\n\nStarting capital in the supplied plan: 100,000 ETB."
        } else {
            "ቤተ ሰልሖም የማህበረሰብ ጤና ስልጠና ማዕከል የግል የስልጠናና የምክር ድርጅት ነው።\n\nራዕይ፦ በኢትዮጵያ በማህበረሰብ ጤና ስልጠና ዘርፍ መሪ ተቋም መሆን።\n\nተልዕኮ፦ ተግባራዊ፣ ዘመናዊና ተመጣጣኝ የጤና ስልጠና መስጠት።\n\nዓላማ፦ በ1ኛ ዓመት 300 ተሳታፊዎችን ማሰልጠንና ከ10 በላይ የጤና ተቋማት ጋር ሽርክና መፍጠር።\n\nየቀረበው መነሻ ካፒታል፦ 100,000 ብር።"
        }
        content.addView(tv(s))
        content.addView(btn(if(english)"Home" else "መነሻ"){showHome()})
        setContentView(root)
    }

    private fun simple(title:String, body:String) {
        val root=base(title); content.addView(tv(body))
        content.addView(btn(if(english)"Home" else "መነሻ"){showHome()}); setContentView(root)
    }

    private fun showAnnouncements() = simple(if(english)"Announcements" else "ማስታወቂያ",
        if(english)"New training announcements will appear here." else "አዳዲስ የስልጠና ማስታወቂያዎች እዚህ ይታያሉ።")
    private fun showCertificate() = simple(if(english)"Certificate" else "ሰርቲፊኬት",
        if(english)"Certificate verification will be connected to official records in a future version." else "የሰርቲፊኬት ማረጋገጫ በቀጣይ ስሪት ከማዕከሉ ኦፊሴላዊ መዝገብ ጋር ይገናኛል።")
    private fun showContact() = simple(if(english)"Contact Us" else "ያግኙን",
        if(english)"Official phone, email and address can be added when provided." else "የኦፊሴላዊ ስልክ፣ ኢሜይል እና አድራሻ መረጃ ሲሰጥ እዚህ ይጨመራል።")
}
