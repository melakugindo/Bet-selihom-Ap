# ቤተ ሰልሖም Android App v1.0

አማርኛ + English የሚደግፍ የመጀመሪያ Android ፕሮጀክት።

የያዘው፦ Home, Trainings, Registration, About Us, Announcements, Certificate, Contact.

ማስታወሻ፦ በቀረበው ቢዝነስ ፕላን 100,000 ብር መነሻ ካፒታል እና 800,000 ብር የወጪ ምሳሌ ስለማይጣጣሙ የፋይናንስ ክፍል በቀጣይ ሊስተካከል ይገባል።
